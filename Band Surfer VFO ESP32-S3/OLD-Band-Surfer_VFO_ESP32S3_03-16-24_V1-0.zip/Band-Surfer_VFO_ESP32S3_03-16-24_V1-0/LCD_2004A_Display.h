#ifndef LCD_2004A_DISPLAY_H
//#define LCD_2004A_DISPLAY_H

//#include <LiquidCrystal_I2C.h>

class LCD_2004A_DISPLAY{

public:
/*
void begin(void);
long FreqDisplay(bool oneHz, long displayFreq);
void modeDisplay(String display_mode);
void vfoDisplay(uint8_t vfo_display);
void vfoRxtx(uint8_t vfoRxtx_display);
void rxtxDisplay(bool txMode);
void tuningstep(uint8_t tstep);
void tuningspeed(uint8_t tspeed);
void altvfofreq(long altvfofreq);
void band_display(String band_name);
void freq_incdisplay(bool oneHz, long displayFreqinc);
*/
private:


}; // end of class
#endif //LCD_2004A_DISPLAY_H